<?php include("conf/config.inc.php");?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Find a Doctor - Doctor Reviews & Ratings | Book Online Instantly – Bookmydoc </title>
<link href="images/favicon.png" type="image/png" rel="shortcut icon">
</head>

<body>
<div align="center"><img src="<?php echo WEB_ROOT;?>/service/public/images/404-error.jpg"></div>
</body>
</html>
