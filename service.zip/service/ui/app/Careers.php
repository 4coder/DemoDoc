<?php
session_start();
include("service/ui/common/header.php"); 
echo $_SESSION['userID'];
?>
<section  class="team-modern-12">
   <div class="container">
      <div class="">
      <div class="menu-nav">
      	<li class="link-li"><a href="<?php echo WEB_ROOT;?>index.php/About">About Us</a></li>
        <li class="link-li"><a href="<?php echo WEB_ROOT;?>index.php/Careers">Careers</a></li>
        <li class="link-li"><a href="<?php echo WEB_ROOT;?>index.php/Contact">Contact Us</a></li>
      </div>
      <div class="content-box">
      <p style="text-align:justify">
      
<h4>Careers... </h4>
<p style="text-align:justify">
sfgsfsdf</p>
</p>
      </div>
      </div>
      </div>
      </section>
      <?php 
	  include("service/ui/common/footer.php"); 
	  ?>